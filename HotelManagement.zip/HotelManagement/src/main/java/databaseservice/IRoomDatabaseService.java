/*entity
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package databaseservice;
import entity.RoomEntity;
import java.util.List;
/**
 *
 * @author dinhthai62001
 */
public interface IRoomDatabaseService {
    List<RoomEntity> getAllRooms();
    int addRoom(RoomEntity entity);
    int updateRoom(RoomEntity entity);
    int deleteRoom(String maPhong); // Thêm dòng này
}
