package databaseservice;

import entity.NhanVienEntity;
import java.util.List;

public interface INhanVienDatabaseService {
    List<NhanVienEntity> getAllNhanViens();
    int addNhanVien(NhanVienEntity entity);
    int updateNhanVien(NhanVienEntity entity);
    int deleteNhanVien(String maNV);
}