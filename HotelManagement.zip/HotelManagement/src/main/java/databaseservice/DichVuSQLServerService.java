package databaseservice;

import entity.DichVuEntity;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dinhthai62001
 */
public class DichVuSQLServerService implements IDichVuDatabaseService {
    private static final String DV_ID = "MaDV";
    private static final String DV_NAME = "TenDV";
    private static final String PRICE = "DonGia";

    private static DichVuSQLServerService instance;

    public static DichVuSQLServerService getInstance() {
        if (instance == null) {
            instance = new DichVuSQLServerService();
        }
        return instance;
    }

    private DichVuSQLServerService() {}

    @Override
    public List<DichVuEntity> getAllDichVu() {
        List<DichVuEntity> list = new ArrayList<>();
        String sql = "SELECT * FROM DichVu";
        try (SQLServerProvider provider = new SQLServerProvider()) {
            ResultSet rs = provider.executeQuery(sql);
            while (rs.next()) {
                list.add(new DichVuEntity(
                        rs.getString(DV_ID),
                        rs.getString(DV_NAME),
                        rs.getDouble(PRICE)
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DichVuSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public int addDichVu(DichVuEntity entity) {
        String sql = String.format("""
                INSERT INTO DichVu (%s, %s, %s)
                VALUES ('%s', N'%s', %.2f)
                """,
                DV_ID, DV_NAME, PRICE,
                entity.maDV(), entity.tenDV(), entity.donGia()
        );
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DichVuSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    @Override
    public int updateDichVu(DichVuEntity entity) {
        String sql = String.format("""
            UPDATE DichVu 
            SET %s = N'%s', %s = %.2f
            WHERE %s = '%s'
            """,
            DV_NAME, entity.tenDV(),
            PRICE, entity.donGia(),
            DV_ID, entity.maDV()
        );

        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DichVuSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public int deleteDichVu(String maDV) {
        String sql = String.format("DELETE FROM DichVu WHERE MaDV = '%s'", maDV);
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DichVuSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
}