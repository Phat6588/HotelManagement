/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import entity.DichVuEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.DichVu;
import com.mycompany.hotelmanagement.BHException;
import databaseservice.IDichVuDatabaseService;

/**
 *
 * @author dinhthai62001
 */
public class DichVuService {
    private static DichVuService instance;

    public static DichVuService getInstance() {
        if (instance == null) {
            instance = new DichVuService();
        }
        return instance;
    }

    private final List<DichVu> dichVuList;
    private IDichVuDatabaseService dichVuDatabaseService;

    private DichVuService() {
        this.dichVuList = new ArrayList<>();
    }

    public List<DichVu> getDichVuList() {
        return dichVuList;
    }

    public void setDichVuDatabaseService(IDichVuDatabaseService dichVuDatabaseService) {
        this.dichVuDatabaseService = dichVuDatabaseService;
    }

    public void loadAllDichVuFromDatabase() {
        this.dichVuList.clear();
        List<DichVuEntity> entityList = this.dichVuDatabaseService.getAllDichVu();
        for (DichVuEntity entity : entityList) {
            try {
                this.dichVuList.add(toModel(entity));
            } catch (BHException ex) {
                Logger.getLogger(DichVuService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public boolean addDichVu(DichVu model) {
        return this.dichVuDatabaseService.addDichVu(toEntity(model)) > 0;
    }

    public boolean updateDichVu(DichVu model) {
        if (this.dichVuDatabaseService == null) {
            throw new IllegalStateException("dichVuDatabaseService chưa được khởi tạo");
        }
        return this.dichVuDatabaseService.updateDichVu(toEntity(model)) > 0;
    }

    public boolean deleteDichVu(String maDV) {
        return dichVuDatabaseService.deleteDichVu(maDV) > 0;
    }

    public DichVu toModel(DichVuEntity entity) throws BHException {
        return new DichVu(
                entity.maDV(),
                entity.tenDV(),
                entity.donGia()
        );
    }

    public DichVuEntity toEntity(DichVu model) {
        return new DichVuEntity(
                model.getMaDV(),
                model.getTenDV(),
                model.getDonGia()
        );
    }
}
