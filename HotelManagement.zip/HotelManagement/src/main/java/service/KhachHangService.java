package service;

import com.mycompany.hotelmanagement.BHException;
import databaseservice.IKhachHangDatabaseService;
import entity.KhachHangEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.KhachHang;

public class KhachHangService {
    private static KhachHangService instance;

    public static KhachHangService getInstance() {
        if (instance == null) {
            instance = new KhachHangService();
        }
        return instance;
    }

    private final List<KhachHang> khachHangList;
    private IKhachHangDatabaseService khachHangDatabaseService;

    private KhachHangService() {
        this.khachHangList = new ArrayList<>();
    }

    public List<KhachHang> getKhachHangList() {
        return khachHangList;
    }

    public void setKhachHangDatabaseService(IKhachHangDatabaseService khachHangDatabaseService) {
        this.khachHangDatabaseService = khachHangDatabaseService;
    }

   public void loadAllKhachHangFromDatabase() {
    if (khachHangDatabaseService == null) {
        throw new IllegalStateException("khachHangDatabaseService chưa được khởi tạo");
    }
    List<KhachHangEntity> entities = khachHangDatabaseService.getAllKhachHang();
    this.khachHangList.clear();
    for (KhachHangEntity e : entities) {
        try {
            this.khachHangList.add(toModel(e));
        } catch (BHException ex) {
            Logger.getLogger(KhachHangService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

    public boolean addKhachHang(KhachHang model) {
        return khachHangDatabaseService.addKhachHang(toEntity(model)) > 0;
    }

    public boolean updateKhachHang(KhachHang model) {
        if (khachHangDatabaseService == null) {
            throw new IllegalStateException("khachHangDatabaseService chưa được khởi tạo");
        }
        return khachHangDatabaseService.updateKhachHang(toEntity(model)) > 0;
    }

    public boolean deleteKhachHang(String maKH) {
        return khachHangDatabaseService.deleteKhachHang(maKH) > 0;
    }

    public KhachHang toModel(KhachHangEntity entity) throws BHException {
        return new KhachHang(
            entity.maKH(),
            entity.maPhong(),
            entity.maDV(),
            entity.tenKH(),
            entity.cmnd(),
            entity.sdt(),
            entity.diaChi(),
            entity.ngayNhan(),
            entity.ngayTra()
        );
    }

    public KhachHangEntity toEntity(KhachHang model) {
        return new KhachHangEntity(
            model.getMaKH(),
            model.getMaPhong(),
            model.getMaDV(),
            model.getTenKH(),
            model.getCmnd(),
            model.getSdt(),
            model.getDiaChi(),
            model.getNgayNhan(),
            model.getNgayTra()
        );
    }
}