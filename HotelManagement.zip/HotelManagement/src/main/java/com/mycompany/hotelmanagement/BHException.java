package com.mycompany.hotelmanagement;

/**
 * BHException
 * @author hasu
 */
public class BHException extends Exception{

    public BHException(String message) {
        super(message);
    }

}
