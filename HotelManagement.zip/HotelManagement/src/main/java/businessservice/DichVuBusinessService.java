package businessservice;

import com.mycompany.hotelmanagement.BHException;
import dto.DichVuDto;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.DichVu;
import service.DichVuService;

public class DichVuBusinessService implements IDichVuBusinessService {

    private static DichVuBusinessService instance;
    private DichVuService dichVuService;

    public static DichVuBusinessService getInstance() {
        if (instance == null) {
            instance = new DichVuBusinessService();
        }
        return instance;
    }

    private DichVuBusinessService() {
        dichVuService = DichVuService.getInstance();
    }
   @Override
    public List<String> getAllDichVuIds() {
        List<String> maDVList = new ArrayList<>();
        for (DichVu model : DichVuService.getInstance().getDichVuList()) {
            maDVList.add(model.getMaDV());
        }
        return maDVList;
    }
    @Override
    public List<DichVuDto> getAllDichVus() {
        List<DichVuDto> list = new ArrayList<>();
        for (DichVu model : dichVuService.getDichVuList()) {
            list.add(toDto(model));
        }
        return list;
    }

    @Override
    public boolean addDichVu(DichVuDto dto) {
        try {
            return dichVuService.addDichVu(toModel(dto));
        } catch (BHException ex) {
            Logger.getLogger(DichVuBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean updateDichVu(DichVuDto dto) {
        try {
            return dichVuService.updateDichVu(toModel(dto));
        } catch (BHException ex) {
            Logger.getLogger(DichVuBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean deleteDichVu(String maDV) {
        return dichVuService.deleteDichVu(maDV);
    }

    private DichVu toModel(DichVuDto dto) throws BHException {
        return new DichVu(dto.getMaDV(), dto.getTenDV(), dto.getDonGia());
    }

    private DichVuDto toDto(DichVu model) {
        return new DichVuDto(model.getMaDV(), model.getTenDV(), model.getDonGia());
    }
}