package businessservice;

import com.mycompany.hotelmanagement.BHException;
import dto.NhanVienDto;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.NhanVien;
import service.NhanVienService;

public class NhanVienBusinessService implements INhanVienBusinessService {

    private static NhanVienBusinessService instance;
    private NhanVienService nhanVienService;

    public static NhanVienBusinessService getInstance() {
        if (instance == null) {
            instance = new NhanVienBusinessService();
        }
        return instance;
    }

    private NhanVienBusinessService() {
    }

    @Override
    public List<NhanVienDto> getAllNhanViens() {
        List<NhanVienDto> list = new ArrayList<>();
        for (NhanVien model : NhanVienService.getInstance().getNhanVienList()) {
            list.add(toDto(model));
        }
        return list;
    }

    @Override
    public boolean addNhanVien(NhanVienDto dto) {
        try {
            return NhanVienService.getInstance().addNhanVien(toModel(dto));
        } catch (BHException ex) {
            Logger.getLogger(NhanVienBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean updateNhanVien(NhanVienDto dto) {
        try {
            return NhanVienService.getInstance().updateNhanVien(toModel(dto));
        } catch (BHException ex) {
            Logger.getLogger(NhanVienBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean deleteNhanVien(String maNV) {
        return NhanVienService.getInstance().deleteNhanVien(maNV);
    }

    private NhanVien toModel(NhanVienDto dto) throws BHException {
        return new NhanVien(dto.getMaNV(), dto.getTenNV(), dto.getChucVu());
    }

    private NhanVienDto toDto(NhanVien model) {
        return new NhanVienDto(model.getMaNV(), model.getTenNV(), model.getChucVu());
    }
}