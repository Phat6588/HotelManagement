package model;

import java.util.Date;

/**
 * DonHang
 *
 * @author hasu
 */
public class DonHang {

    String maDH;
    KhachHang khachHang;
    Date ngalyLapDH;
}
