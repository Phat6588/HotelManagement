package ui;

import businessservice.IKhachHangBusinessService;
import businessservice.KhachHangBusinessService;
import dto.KhachHangDto;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

public class UserManagement extends JPanel {

    private IKhachHangBusinessService khachHangBusinessService;
    private JTable tblKhachHang;
    private DefaultTableModel tableModel;
    private JButton btnThem, btnSua, btnXoa;
    private List<String> danhSachMaPhong;
    private List<String> danhSachMaDV;

    public UserManagement() {
        setLayout(new BorderLayout());

        String[] columns = {"Mã KH", "Mã Phòng", "Mã DV", "Tên KH", "CMND", "SDT", "Địa Chỉ", "Ngày Nhận", "Ngày Trả"};
        tableModel = new DefaultTableModel(columns, 0);
        tblKhachHang = new JTable(tableModel);
        add(new JScrollPane(tblKhachHang), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        btnThem = new JButton("Thêm");
        btnSua = new JButton("Sửa");
        btnXoa = new JButton("Xóa");
        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        add(buttonPanel, BorderLayout.SOUTH);

        btnThem.addActionListener(e -> moFormThem());
        btnSua.addActionListener(e -> {
            int selectedRow = tblKhachHang.getSelectedRow();
            if (selectedRow >= 0) {
                moFormSua(selectedRow);
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng để sửa.");
            }
        });
        btnXoa.addActionListener(e -> xoaKhachHang());

        tblKhachHang.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tblKhachHang.getSelectedRow() != -1) {
                    moFormSua(tblKhachHang.getSelectedRow());
                }
            }
        });
    }

    public void setKhachHangBusinessService(IKhachHangBusinessService service) {
        this.khachHangBusinessService = service;
        loadKhachHangData();
    }

    public void setDanhSachMaPhong(List<String> danhSachMaPhong) {
        this.danhSachMaPhong = danhSachMaPhong;
    }

    public void setDanhSachMaDV(List<String> danhSachMaDV) {
        this.danhSachMaDV = danhSachMaDV;
    }

  private void loadKhachHangData() {
    System.out.println("Đang load lại danh sách khách hàng...");
    List<KhachHangDto> list = KhachHangBusinessService.getInstance().getAllKhachHang();
    tableModel.setRowCount(0);
    for (KhachHangDto dto : list) {
        tableModel.addRow(new Object[]{
    dto.getMaKH(),
    dto.getMaPhong(),
    dto.getMaDV(),
    dto.getTenKH(),
    dto.getCmnd(),
    dto.getSdt(),
    dto.getDiaChi(),
    dto.getNgayNhan(),
    dto.getNgayTra()
});
    }
    System.out.println("Số lượng khách hàng sau reload: " + list.size());
}

    private void moFormThem() {
        JDialog dialog = new JDialog((Frame) null, "Thêm Khách Hàng", true);
        dialog.setSize(500, 450);
        dialog.setLayout(null);

        JTextField txtMaKH = new JTextField();

        JComboBox<String> cmbMaPhong = new JComboBox<>();
        cmbMaPhong.setEditable(false);
        if (danhSachMaPhong != null) {
            for (String maPhong : danhSachMaPhong) {
                cmbMaPhong.addItem(maPhong);
            }
        }

        JComboBox<String> cmbMaDV = new JComboBox<>();
        cmbMaDV.setEditable(false);
        if (danhSachMaDV != null) {
            for (String maDV : danhSachMaDV) {
                cmbMaDV.addItem(maDV);
            }
        }
        JTextField txtTenKH = new JTextField();
        JTextField txtCMND = new JTextField();
        JTextField txtSDT = new JTextField();
        JTextField txtDiaChi = new JTextField();
        JTextField txtNgayNhan = new JTextField();
        JTextField txtNgayTra = new JTextField();
        JButton btnLuu = new JButton("Lưu");

        String[] labels = {"Mã KH:", "Mã Phòng:", "Mã DV:", "Tên KH:", "CMND:", "SDT:", "Địa Chỉ:", "Ngày Nhận (yyyy-MM-dd):", "Ngày Trả (yyyy-MM-dd):"};
        JComponent[] fields = {txtMaKH, cmbMaPhong, cmbMaDV, txtTenKH, txtCMND, txtSDT, txtDiaChi, txtNgayNhan, txtNgayTra};

        for (int i = 0; i < labels.length; i++) {
            JLabel lbl = new JLabel(labels[i]);
            lbl.setBounds(20, 20 + i * 40, 160, 25);
            fields[i].setBounds(180, 20 + i * 40, 280, 25);
            dialog.add(lbl);
            dialog.add(fields[i]);
        }
        btnLuu.setBounds(200, 380, 80, 30);
        dialog.add(btnLuu);

        btnLuu.addActionListener(e -> {
            try {
                String maKH = txtMaKH.getText().trim();
                String maPhong = ((JTextField) cmbMaPhong.getEditor().getEditorComponent()).getText().trim();
               String maDV = ((JTextField) cmbMaDV.getEditor().getEditorComponent()).getText().trim();
                String tenKH = txtTenKH.getText().trim();
                String cmnd = txtCMND.getText().trim();
                String sdt = txtSDT.getText().trim();
                String diaChi = txtDiaChi.getText().trim();
                LocalDate ngayNhan = LocalDate.parse(txtNgayNhan.getText().trim());
                LocalDate ngayTra = LocalDate.parse(txtNgayTra.getText().trim());

                if (maKH.isEmpty() || tenKH.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Mã KH và Tên KH không được để trống.");
                    return;
                }

                KhachHangDto dto = new KhachHangDto(maKH, maPhong, maDV, tenKH, cmnd, sdt, diaChi, ngayNhan, ngayTra);
                if (khachHangBusinessService.addKhachHang(dto)) {
                    
                    dialog.dispose();
                    JOptionPane.showMessageDialog(this, "Thêm khách hàng thành công.");
                    loadKhachHangData();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Thêm khách hàng thất bại.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Lỗi nhập dữ liệu: " + ex.getMessage());
            }
        });

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

   private void moFormSua(int rowIndex) {
    JDialog dialog = new JDialog((Frame) null, "Sửa Khách Hàng", true);
    dialog.setSize(500, 450);
    dialog.setLayout(null);

    JTextField txtMaKH = new JTextField(tableModel.getValueAt(rowIndex, 0).toString());
    txtMaKH.setEnabled(false);

    JComboBox<String> cmbMaPhong = new JComboBox<>();
    if (danhSachMaPhong != null) {
        for (String maPhong : danhSachMaPhong) {
            cmbMaPhong.addItem(maPhong);
        }
    }
    cmbMaPhong.setSelectedItem(tableModel.getValueAt(rowIndex, 1).toString());

    JComboBox<String> cmbMaDV = new JComboBox<>();
    if (danhSachMaDV != null) {
        for (String maDV : danhSachMaDV) {
            cmbMaDV.addItem(maDV);
        }
    }
    cmbMaDV.setSelectedItem(tableModel.getValueAt(rowIndex, 2).toString());

    JTextField txtTenKH = new JTextField(tableModel.getValueAt(rowIndex, 3).toString());
    JTextField txtCMND = new JTextField(tableModel.getValueAt(rowIndex, 4).toString());
    JTextField txtSDT = new JTextField(tableModel.getValueAt(rowIndex, 5).toString());
    JTextField txtDiaChi = new JTextField(tableModel.getValueAt(rowIndex, 6).toString());
    JTextField txtNgayNhan = new JTextField(tableModel.getValueAt(rowIndex, 7).toString());
    JTextField txtNgayTra = new JTextField(tableModel.getValueAt(rowIndex, 8).toString());
    JButton btnLuu = new JButton("Lưu");

    String[] labels = {"Mã KH:", "Mã Phòng:", "Mã DV:", "Tên KH:", "CMND:", "SDT:", "Địa Chỉ:", "Ngày Nhận (yyyy-MM-dd):", "Ngày Trả (yyyy-MM-dd):"};
    JComponent[] fields = {txtMaKH, cmbMaPhong, cmbMaDV, txtTenKH, txtCMND, txtSDT, txtDiaChi, txtNgayNhan, txtNgayTra};

    for (int i = 0; i < labels.length; i++) {
        JLabel lbl = new JLabel(labels[i]);
        lbl.setBounds(20, 20 + i * 40, 160, 25);
        fields[i].setBounds(180, 20 + i * 40, 280, 25);
        dialog.add(lbl);
        dialog.add(fields[i]);
    }

    btnLuu.setBounds(200, 380, 80, 30);
    dialog.add(btnLuu);

    btnLuu.addActionListener(e -> {
        try {
            String maKH = txtMaKH.getText().trim();
            String maPhong = cmbMaPhong.getSelectedItem().toString().trim();
            String maDV = cmbMaDV.getSelectedItem().toString().trim();
            String tenKH = txtTenKH.getText().trim();
            String cmnd = txtCMND.getText().trim();
            String sdt = txtSDT.getText().trim();
            String diaChi = txtDiaChi.getText().trim();
            LocalDate ngayNhan = LocalDate.parse(txtNgayNhan.getText().trim());
            LocalDate ngayTra = LocalDate.parse(txtNgayTra.getText().trim());

            KhachHangDto dto = new KhachHangDto(maKH, maPhong, maDV, tenKH, cmnd, sdt, diaChi, ngayNhan, ngayTra);
            if (khachHangBusinessService.updateKhachHang(dto)) {
                loadKhachHangData();
                dialog.dispose();
                JOptionPane.showMessageDialog(this, "Cập nhật khách hàng thành công.");
            } else {
                JOptionPane.showMessageDialog(dialog, "Cập nhật khách hàng thất bại.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog, "Lỗi nhập dữ liệu: " + ex.getMessage());
        }
    });

    dialog.setLocationRelativeTo(this);
    dialog.setVisible(true);
}
    private void xoaKhachHang() {
    int selectedRow = tblKhachHang.getSelectedRow();
    if (selectedRow >= 0) {
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa khách hàng này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            String maKH = tableModel.getValueAt(selectedRow, 0).toString();
            System.out.println(">>> Đang xóa khách hàng mã: " + maKH);

            boolean result = khachHangBusinessService.deleteKhachHang(maKH);
            System.out.println(">>> Kết quả hàm deleteKhachHang(): " + result);

            if (result) {
                loadKhachHangData();
                JOptionPane.showMessageDialog(this, "Xóa khách hàng thành công.");
            } else {
                JOptionPane.showMessageDialog(this, "Xóa khách hàng thất bại.");
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng để xóa.");
    }
}
}
