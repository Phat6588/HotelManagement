package ui;

import businessservice.IRoomBusinessService;
import dto.RoomDto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class RoomManagement extends JPanel {
    private JTable roomTable;
    private DefaultTableModel tableModel;
    private JButton btnThem, btnSua, btnXoa;
    private IRoomBusinessService roomBusinessSercive;

    public RoomManagement() {
        setLayout(new BorderLayout());

        // Bảng hiển thị phòng
        tableModel = new DefaultTableModel(new Object[]{"Mã phòng", "Tên phòng", "Tình trạng", "Giá phòng"}, 0);
        roomTable = new JTable(tableModel);
        add(new JScrollPane(roomTable), BorderLayout.CENTER);

        // Panel chứa nút
        JPanel buttonPanel = new JPanel();
        btnThem = new JButton("Thêm");
        btnSua = new JButton("Sửa");
        btnXoa = new JButton("Xóa");

        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        add(buttonPanel, BorderLayout.SOUTH);

        // Gán sự kiện nút
        btnThem.addActionListener(e -> moFormThem());
        btnSua.addActionListener(e -> {
            int selectedRow = roomTable.getSelectedRow();
            if (selectedRow >= 0) {
                moFormSua(selectedRow);
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng để sửa.");
            }
        });
        btnXoa.addActionListener(e -> xoaPhong());

        // Sự kiện click đúp để sửa
        roomTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && roomTable.getSelectedRow() != -1) {
                    moFormSua(roomTable.getSelectedRow());
                }
            }
        });
    }

    public void setRoomBusinessSercive(IRoomBusinessService roomBusinessSercive) {
        this.roomBusinessSercive = roomBusinessSercive;
        loadRoomsFromDB(); // Tải dữ liệu sau khi gán service
    }

    private void loadRoomsFromDB() {
        if (roomBusinessSercive == null) return;

        tableModel.setRowCount(0); 
        var roomList = roomBusinessSercive.getAllRooms();
        for (var room : roomList) {
            tableModel.addRow(new Object[]{
                room.getMaPhong(),
                room.getTenPhong(),
                room.getTinhTrang(),
                room.getGiaPhong()
            });
        }
    }

    private void moFormThem() {
        JDialog dialog = new JDialog((Frame) null, "Thêm phòng", true);
        dialog.setSize(400, 280);
        dialog.setLayout(null);

        JLabel lblMa = new JLabel("Mã phòng:");
        JTextField txtMa = new JTextField();
        JLabel lblTen = new JLabel("Tên phòng:");
        JTextField txtTen = new JTextField();
        JLabel lblTinhTrang = new JLabel("Tình trạng:");
        JComboBox<String> cbTinhTrang = new JComboBox<>(new String[]{"Trống", "Đang sử dụng", "Bảo trì"});
        JLabel lblGia = new JLabel("Giá phòng:");
        JTextField txtGia = new JTextField();

        JButton btnLuu = new JButton("Lưu");

        lblMa.setBounds(30, 20, 100, 25);
        txtMa.setBounds(150, 20, 200, 25);
        lblTen.setBounds(30, 60, 100, 25);
        txtTen.setBounds(150, 60, 200, 25);
        lblTinhTrang.setBounds(30, 100, 100, 25);
        cbTinhTrang.setBounds(150, 100, 200, 25);
        lblGia.setBounds(30, 140, 100, 25);
        txtGia.setBounds(150, 140, 200, 25);
        btnLuu.setBounds(150, 190, 80, 30);

        dialog.add(lblMa); dialog.add(txtMa);
        dialog.add(lblTen); dialog.add(txtTen);
        dialog.add(lblTinhTrang); dialog.add(cbTinhTrang);
        dialog.add(lblGia); dialog.add(txtGia);
        dialog.add(btnLuu);

        btnLuu.addActionListener(e -> {
            String ma = txtMa.getText().trim();
            String ten = txtTen.getText().trim();
            String tinhTrang = cbTinhTrang.getSelectedItem().toString();
            String giaStr = txtGia.getText().trim();

            if (ma.isEmpty() || ten.isEmpty() || giaStr.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập đầy đủ thông tin.");
                return;
            }

            try {
                double gia = Double.parseDouble(giaStr);

                RoomDto roomDto = new RoomDto(ma, ten, tinhTrang, gia);

                boolean isAdded = roomBusinessSercive.addRoom(roomDto);

                if (isAdded) {
                    tableModel.addRow(new Object[]{ma, ten, tinhTrang, gia});
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Lỗi thêm phòng.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Giá phòng phải là số.");
            }
        });

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

  private void moFormSua(int rowIndex) {
    JDialog dialog = new JDialog((Frame) null, "Sửa phòng", true);
    dialog.setSize(400, 280);
    dialog.setLayout(null);

    String maPhong = tableModel.getValueAt(rowIndex, 0).toString(); // Lấy mã phòng gốc

    JLabel lblTen = new JLabel("Tên phòng:");
    JTextField txtTen = new JTextField(tableModel.getValueAt(rowIndex, 1).toString());
    JLabel lblTinhTrang = new JLabel("Tình trạng:");
    JComboBox<String> cbTinhTrang = new JComboBox<>(new String[]{"Trống", "Đang sử dụng", "Bảo trì"});
    cbTinhTrang.setSelectedItem(tableModel.getValueAt(rowIndex, 2));
    JLabel lblGia = new JLabel("Giá phòng:");
    JTextField txtGia = new JTextField(tableModel.getValueAt(rowIndex, 3).toString());

    JButton btnLuu = new JButton("Lưu");

    lblTen.setBounds(30, 20, 100, 25);
    txtTen.setBounds(150, 20, 200, 25);
    lblTinhTrang.setBounds(30, 60, 100, 25);
    cbTinhTrang.setBounds(150, 60, 200, 25);
    lblGia.setBounds(30, 100, 100, 25);
    txtGia.setBounds(150, 100, 200, 25);
    btnLuu.setBounds(150, 150, 80, 30);

    dialog.add(lblTen); dialog.add(txtTen);
    dialog.add(lblTinhTrang); dialog.add(cbTinhTrang);
    dialog.add(lblGia); dialog.add(txtGia);
    dialog.add(btnLuu);

    btnLuu.addActionListener(e -> {
        String ten = txtTen.getText().trim();
        String tinhTrang = cbTinhTrang.getSelectedItem().toString();
        String giaStr = txtGia.getText().trim();

        if (ten.isEmpty() || giaStr.isEmpty()) {
            JOptionPane.showMessageDialog(dialog, "Vui lòng nhập đầy đủ thông tin.");
            return;
        }

        try {
            double gia = Double.parseDouble(giaStr);

            RoomDto roomDto = new RoomDto(maPhong, ten, tinhTrang, gia);
            boolean isUpdated = roomBusinessSercive.updateRoom(roomDto); // Cập nhật trong DB

            if (isUpdated) {
                // Cập nhật lại bảng hiển thị
                tableModel.setValueAt(ten, rowIndex, 1);
                tableModel.setValueAt(tinhTrang, rowIndex, 2);
                tableModel.setValueAt(gia, rowIndex, 3);
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Không thể cập nhật phòng.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(dialog, "Giá phòng phải là số.");
        }
    });

    dialog.setLocationRelativeTo(this);
    dialog.setVisible(true);
}

    private void xoaPhong() {
    int selectedRow = roomTable.getSelectedRow();
    if (selectedRow >= 0) {
        String maPhong = tableModel.getValueAt(selectedRow, 0).toString();
        
        int confirm = JOptionPane.showConfirmDialog(this, 
                "Bạn có chắc chắn muốn xoá phòng " + maPhong + "?", 
                "Xác nhận xoá", 
                JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean isDeleted = roomBusinessSercive.deleteRoom(maPhong);
            if (isDeleted) {
                tableModel.removeRow(selectedRow);
            } else {
                JOptionPane.showMessageDialog(this, "Không thể xoá phòng.");
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng để xoá.");
    }
}
}