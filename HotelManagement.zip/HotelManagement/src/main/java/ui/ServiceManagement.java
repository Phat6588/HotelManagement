package ui;

import businessservice.IDichVuBusinessService;
import dto.DichVuDto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ServiceManagement extends JPanel {
    private IDichVuBusinessService dichVuBusinessService;

    private JTable tblDichVu;
    private DefaultTableModel tableModel;
    private JButton btnThem, btnSua, btnXoa;

    public ServiceManagement() {
        setLayout(new BorderLayout());

        // Tạo bảng
        String[] columns = {"Mã DV", "Tên dịch vụ", "Đơn giá"};
        tableModel = new DefaultTableModel(columns, 0);
        tblDichVu = new JTable(tableModel);
        add(new JScrollPane(tblDichVu), BorderLayout.CENTER);

        // Tạo panel nút
        JPanel buttonPanel = new JPanel();
        btnThem = new JButton("Thêm");
        btnSua = new JButton("Sửa");
        btnXoa = new JButton("Xóa");
        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        add(buttonPanel, BorderLayout.SOUTH);

        // Sự kiện nút
        btnThem.addActionListener(e -> moFormThem());
        btnSua.addActionListener(e -> {
            int selectedRow = tblDichVu.getSelectedRow();
            if (selectedRow >= 0) {
                moFormSua(selectedRow);
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn dịch vụ để sửa.");
            }
        });
        btnXoa.addActionListener(e -> xoaDichVu());

        // Double-click để sửa
        tblDichVu.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tblDichVu.getSelectedRow() != -1) {
                    moFormSua(tblDichVu.getSelectedRow());
                }
            }
        });
    }

    public void setDichVuBusinessService(IDichVuBusinessService service) {
        this.dichVuBusinessService = service;
        loadDichVuData();
    }

    private void loadDichVuData() {
        if (dichVuBusinessService == null) return;

        List<DichVuDto> list = dichVuBusinessService.getAllDichVus();
        tableModel.setRowCount(0);
        for (DichVuDto dv : list) {
            tableModel.addRow(new Object[]{
                dv.getMaDV(),
                dv.getTenDV(),
                dv.getDonGia()
            });
        }
    }

    private void moFormThem() {
        JDialog dialog = new JDialog((Frame) null, "Thêm dịch vụ", true);
        dialog.setSize(400, 220);
        dialog.setLayout(null);

        JLabel lblMa = new JLabel("Mã DV:");
        JTextField txtMa = new JTextField();
        JLabel lblTen = new JLabel("Tên dịch vụ:");
        JTextField txtTen = new JTextField();
        JLabel lblGia = new JLabel("Đơn giá:");
        JTextField txtGia = new JTextField();

        JButton btnLuu = new JButton("Lưu");

        lblMa.setBounds(30, 20, 100, 25);
        txtMa.setBounds(150, 20, 200, 25);
        lblTen.setBounds(30, 60, 100, 25);
        txtTen.setBounds(150, 60, 200, 25);
        lblGia.setBounds(30, 100, 100, 25);
        txtGia.setBounds(150, 100, 200, 25);
        btnLuu.setBounds(150, 140, 80, 30);

        dialog.add(lblMa); dialog.add(txtMa);
        dialog.add(lblTen); dialog.add(txtTen);
        dialog.add(lblGia); dialog.add(txtGia);
        dialog.add(btnLuu);

        btnLuu.addActionListener(e -> {
            String ma = txtMa.getText().trim();
            String ten = txtTen.getText().trim();
            String giaStr = txtGia.getText().trim();

            if (ma.isEmpty() || ten.isEmpty() || giaStr.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập đầy đủ thông tin.");
                return;
            }

            try {
                double gia = Double.parseDouble(giaStr);

                DichVuDto dto = new DichVuDto(ma, ten, gia);
                boolean isAdded = dichVuBusinessService.addDichVu(dto);

                if (isAdded) {
                    tableModel.addRow(new Object[]{ma, ten, gia});
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Lỗi thêm dịch vụ.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Đơn giá phải là số.");
            }
        });

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void moFormSua(int rowIndex) {
        JDialog dialog = new JDialog((Frame) null, "Sửa dịch vụ", true);
        dialog.setSize(400, 220);
        dialog.setLayout(null);

        String maDV = tableModel.getValueAt(rowIndex, 0).toString();

        JLabel lblTen = new JLabel("Tên dịch vụ:");
        JTextField txtTen = new JTextField(tableModel.getValueAt(rowIndex, 1).toString());
        JLabel lblGia = new JLabel("Đơn giá:");
        JTextField txtGia = new JTextField(tableModel.getValueAt(rowIndex, 2).toString());

        JButton btnLuu = new JButton("Lưu");

        lblTen.setBounds(30, 20, 100, 25);
        txtTen.setBounds(150, 20, 200, 25);
        lblGia.setBounds(30, 60, 100, 25);
        txtGia.setBounds(150, 60, 200, 25);
        btnLuu.setBounds(150, 100, 80, 30);

        dialog.add(lblTen); dialog.add(txtTen);
        dialog.add(lblGia); dialog.add(txtGia);
        dialog.add(btnLuu);

        btnLuu.addActionListener(e -> {
            String ten = txtTen.getText().trim();
            String giaStr = txtGia.getText().trim();

            if (ten.isEmpty() || giaStr.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập đầy đủ thông tin.");
                return;
            }

            try {
                double gia = Double.parseDouble(giaStr);

                DichVuDto dto = new DichVuDto(maDV, ten, gia);
                boolean isUpdated = dichVuBusinessService.updateDichVu(dto);

                if (isUpdated) {
                    tableModel.setValueAt(ten, rowIndex, 1);
                    tableModel.setValueAt(gia, rowIndex, 2);
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Không thể cập nhật dịch vụ.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Đơn giá phải là số.");
            }
        });

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void xoaDichVu() {
        int selectedRow = tblDichVu.getSelectedRow();
        if (selectedRow >= 0) {
            String maDV = tableModel.getValueAt(selectedRow, 0).toString();

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Bạn có chắc chắn muốn xoá dịch vụ " + maDV + "?",
                    "Xác nhận xoá",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                boolean isDeleted = dichVuBusinessService.deleteDichVu(maDV);
                if (isDeleted) {
                    tableModel.removeRow(selectedRow);
                } else {
                    JOptionPane.showMessageDialog(this, "Không thể xoá dịch vụ.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dịch vụ để xoá.");
        }
    }
}