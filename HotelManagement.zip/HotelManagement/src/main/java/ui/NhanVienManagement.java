package ui;

import businessservice.INhanVienBusinessService;
import dto.NhanVienDto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class NhanVienManagement extends JPanel {
    private JTable nvTable;
    private DefaultTableModel tableModel;
    private JButton btnThem, btnSua, btnXoa;
    private INhanVienBusinessService nhanVienBusinessService;

    public NhanVienManagement() {
        setLayout(new BorderLayout());

        // Bảng hiển thị nhân viên
        tableModel = new DefaultTableModel(new Object[]{"Mã NV", "Tên NV", "Chức vụ"}, 0);
        nvTable = new JTable(tableModel);
        add(new JScrollPane(nvTable), BorderLayout.CENTER);

        // Panel chứa nút
        JPanel buttonPanel = new JPanel();
        btnThem = new JButton("Thêm");
        btnSua = new JButton("Sửa");
        btnXoa = new JButton("Xóa");

        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        add(buttonPanel, BorderLayout.SOUTH);

        // Gán sự kiện nút
        btnThem.addActionListener(e -> moFormThem());
        btnSua.addActionListener(e -> {
            int selectedRow = nvTable.getSelectedRow();
            if (selectedRow >= 0) {
                moFormSua(selectedRow);
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên để sửa.");
            }
        });
        btnXoa.addActionListener(e -> xoaNhanVien());

        // Sự kiện click đúp để sửa
        nvTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && nvTable.getSelectedRow() != -1) {
                    moFormSua(nvTable.getSelectedRow());
                }
            }
        });
    }

    public void setNhanVienBusinessService(INhanVienBusinessService service) {
        this.nhanVienBusinessService = service;
        loadNhanViensFromDB();
    }

    private void loadNhanViensFromDB() {
        if (nhanVienBusinessService == null) return;

        tableModel.setRowCount(0);
        var list = nhanVienBusinessService.getAllNhanViens();
        for (var nv : list) {
            tableModel.addRow(new Object[]{
                nv.getMaNV(),
                nv.getTenNV(),
                nv.getChucVu()
            });
        }
    }

    private void moFormThem() {
        JDialog dialog = new JDialog((Frame) null, "Thêm nhân viên", true);
        dialog.setSize(400, 250);
        dialog.setLayout(null);

        JLabel lblMa = new JLabel("Mã NV:");
        JTextField txtMa = new JTextField();
        JLabel lblTen = new JLabel("Tên NV:");
        JTextField txtTen = new JTextField();
        JLabel lblChucVu = new JLabel("Chức vụ:");
        JTextField txtChucVu = new JTextField();

        JButton btnLuu = new JButton("Lưu");

        lblMa.setBounds(30, 20, 100, 25);
        txtMa.setBounds(150, 20, 200, 25);
        lblTen.setBounds(30, 60, 100, 25);
        txtTen.setBounds(150, 60, 200, 25);
        lblChucVu.setBounds(30, 100, 100, 25);
        txtChucVu.setBounds(150, 100, 200, 25);
        btnLuu.setBounds(150, 150, 80, 30);

        dialog.add(lblMa); dialog.add(txtMa);
        dialog.add(lblTen); dialog.add(txtTen);
        dialog.add(lblChucVu); dialog.add(txtChucVu);
        dialog.add(btnLuu);

        btnLuu.addActionListener(e -> {
            String ma = txtMa.getText().trim();
            String ten = txtTen.getText().trim();
            String chucVu = txtChucVu.getText().trim();

            if (ma.isEmpty() || ten.isEmpty() || chucVu.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập đầy đủ thông tin.");
                return;
            }

            NhanVienDto dto = new NhanVienDto(ma, ten, chucVu);
            boolean isAdded = nhanVienBusinessService.addNhanVien(dto);

            if (isAdded) {
                tableModel.addRow(new Object[]{ma, ten, chucVu});
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Không thể thêm nhân viên.");
            }
        });

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void moFormSua(int rowIndex) {
        JDialog dialog = new JDialog((Frame) null, "Sửa nhân viên", true);
        dialog.setSize(400, 250);
        dialog.setLayout(null);

        String maNV = tableModel.getValueAt(rowIndex, 0).toString();

        JLabel lblTen = new JLabel("Tên NV:");
        JTextField txtTen = new JTextField(tableModel.getValueAt(rowIndex, 1).toString());
        JLabel lblChucVu = new JLabel("Chức vụ:");
        JTextField txtChucVu = new JTextField(tableModel.getValueAt(rowIndex, 2).toString());

        JButton btnLuu = new JButton("Lưu");

        lblTen.setBounds(30, 20, 100, 25);
        txtTen.setBounds(150, 20, 200, 25);
        lblChucVu.setBounds(30, 60, 100, 25);
        txtChucVu.setBounds(150, 60, 200, 25);
        btnLuu.setBounds(150, 110, 80, 30);

        dialog.add(lblTen); dialog.add(txtTen);
        dialog.add(lblChucVu); dialog.add(txtChucVu);
        dialog.add(btnLuu);

        btnLuu.addActionListener(e -> {
            String ten = txtTen.getText().trim();
            String chucVu = txtChucVu.getText().trim();

            if (ten.isEmpty() || chucVu.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập đầy đủ thông tin.");
                return;
            }

            NhanVienDto dto = new NhanVienDto(maNV, ten, chucVu);
            boolean isUpdated = nhanVienBusinessService.updateNhanVien(dto);

            if (isUpdated) {
                tableModel.setValueAt(ten, rowIndex, 1);
                tableModel.setValueAt(chucVu, rowIndex, 2);
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Không thể cập nhật nhân viên.");
            }
        });

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void xoaNhanVien() {
        int selectedRow = nvTable.getSelectedRow();
        if (selectedRow >= 0) {
            String maNV = tableModel.getValueAt(selectedRow, 0).toString();

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Bạn có chắc chắn muốn xoá nhân viên " + maNV + "?",
                    "Xác nhận xoá",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                boolean isDeleted = nhanVienBusinessService.deleteNhanVien(maNV);
                if (isDeleted) {
                    tableModel.removeRow(selectedRow);
                } else {
                    JOptionPane.showMessageDialog(this, "Không thể xoá nhân viên.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên để xoá.");
        }
    }
}