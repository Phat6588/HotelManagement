package dto;

import java.util.Date;

/**
 * DonHangDto
 *
 * @author hasu
 */
public class DonHangDto {

    String maDH;
    KhachHangDto khachHang;
    Date ngalyLapDH;
}
