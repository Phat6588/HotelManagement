package dto;

public class RoomDto {
    private String maPhong;
    private String tenPhong;
    private String tinhTrang;
    private double giaPhong;

    public RoomDto(String maPhong, String tenPhong, String tinhTrang, double giaPhong) {
        this.maPhong = maPhong;
        this.tenPhong = tenPhong;
        this.tinhTrang = tinhTrang;
        this.giaPhong = giaPhong;
    }

    public String getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(String maPhong) {
        this.maPhong = maPhong;
    }

    public String getTenPhong() {
        return tenPhong;
    }

    public void setTenPhong(String tenPhong) {
        this.tenPhong = tenPhong;
    }

    public String getTinhTrang() {
        return tinhTrang;
    }

    public void setTinhTrang(String tinhTrang) {
        this.tinhTrang = tinhTrang;
    }

    public double getGiaPhong() {
        return giaPhong;
    }

    public void setGiaPhong(double giaPhong) {
        this.giaPhong = giaPhong;
    }
}