package entity;

/**
 *
 * @author dinhthai62001
 */
public record RoomEntity(String maPhong, String tenPhong, String tinhTrang, double giaPhong) {}