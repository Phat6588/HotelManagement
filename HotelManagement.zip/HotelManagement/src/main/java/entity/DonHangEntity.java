package entity;

import java.sql.Date;

/**
 * DonHangEntity
 *
 * @author hasu
 */
public record DonHangEntity(
        String maDH,
        String maKH,
        Date ngayLapDH) {

}
