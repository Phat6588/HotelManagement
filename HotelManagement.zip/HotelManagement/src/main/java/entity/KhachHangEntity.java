package entity;

import java.sql.Date;
import java.time.LocalDate;
/**
 *
 * @author hasu
 */
public record KhachHangEntity(
    String maKH,       
    String maPhong,    
    String maDV,       
    String tenKH,      
    String cmnd,       
    String sdt,       
    String diaChi,     
    LocalDate ngayNhan,
    LocalDate ngayTra  
) {}
