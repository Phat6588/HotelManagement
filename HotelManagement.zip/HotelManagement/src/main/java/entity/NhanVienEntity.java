package entity;

/**
 *
 * @author dinhthai62001
 */
public record NhanVienEntity(String maNV, String tenNV, String chucVu) {}